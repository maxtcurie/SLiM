#https://youtu.be/cONc0NcKE7s
from .SLiM_obj import mode_finder
import sys
sys.path.insert(1, './Tools')
sys.path.insert(1, './SLiM_NN')
from .SLiM_NN import Dispersion_NN

#from .Tools import interp